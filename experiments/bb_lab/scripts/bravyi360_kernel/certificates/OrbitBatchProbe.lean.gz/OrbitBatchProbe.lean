import Mathlib.Data.Nat.Bitwise
set_option maxRecDepth 400000
set_option maxHeartbeats 0
namespace OrbitBatchProbe
def lo2 : Nat := 530545731122305832099624667
def hi1 : Nat := 707394308163074442799499556
def yrot (r v : Nat) : Nat := ((v &&& (r*lo2)) <<< 1) ||| ((v &&& (r*hi1)) >>> 2)
def xrot (r v x : Nat) : Nat :=
  let s := 3*x
  ((v >>> s) &&& ((2^(45-s)-1)*(1+2^45)*r)) |||
    ((v <<< (45-s)) &&& (((2^s-1) <<< (45-s))*(1+2^45)*r))
def tr (r v i : Nat) : Nat :=
  xrot r (if i < 15 then v else if i < 30 then yrot r v else yrot r (yrot r v)) (i%15)
def batchCheck (r v expected : Nat) : Bool :=
  let s := r <<< 90
  let l := r*(2^90-1)
  ((List.range 45).all fun i => (((tr r v i+s-v) &&& s) == s)) &&
    (((List.range 45).foldl (fun acc i => acc + ((s ^^^ (((tr r v i ^^^ v)+l) &&& s)) >>> 90)) 0) == expected)
def reps : Nat := 0
