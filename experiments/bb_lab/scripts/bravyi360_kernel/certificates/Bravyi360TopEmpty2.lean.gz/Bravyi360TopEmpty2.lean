import Bravyi360TopEmpty2Data
import Mathlib.Tactic.FinCases

namespace Quantum.Stabilizer.Homological.BB.Bravyi360.TopEmpty
open F2Mask FiberData PackedDigits

/-- A checked matrix-dual pair census excludes the corresponding physical top fiber. -/
theorem cap2_impossible_of_data (beta target word : Nat) (planes : List (Nat × Nat))
    (hb : beta < 2^180) (hw : word < 2^180)
    (hduals : dualPlaneCertificate 180 8 topDualColumns beta planes target)
    (hpairs : filterPlanes ((planes.map Prod.snd).map
      (fastPairPlane 256 7 26 cap2SpreadTable cap2Rep)) target
      (fastPairDomain 256 7 26 cap2SpreadTable cap2Rep beta) = 0)
    (he : reconX topEColumns word = reconX topRColumns beta)
    (hoff : bitCount 180 (outsideMask word beta) ≤ 2) : False := by
  obtain ⟨hbound,hdisjoint⟩ := outsideMask_bounded_disjoint 180 word beta hw
  have hconstraints := dualPlaneCertificate_constraints 180 8 topDualColumns beta
    (outsideMask word beta) planes target hbound
    (fun coeff hann => topDual_constraint coeff beta word hw hann he) hduals
  have hcheck := hpairs
  rw [fastPairFilter_eq 256 7 26 cap2SpreadTable cap2Rep (by decide) cap2_lookup cap2_rep] at hcheck
  exact cap_two_impossible 180 8 256 182 beta (outsideMask word beta) target
    (planes.map Prod.snd) (by decide) (by decide) (by decide) (by decide) hb hbound hoff hdisjoint
    (dualPlaneCertificate_bounded 180 8 topDualColumns beta planes target hduals) hconstraints hcheck
/-- Every listed top cap-two fiber
